
$("document").ready(function () {
    $("#mainChessBoard tr:odd td:odd,#mainChessBoard tr:even td:even").css("background-color", "#AAAAAA");
    $("#mainChessBoard tr:even td:odd,#mainChessBoard tr:odd td:even").css("background-color", "#DDDDDD");

    /* CSS Styles */
    /* var height = $('#mainChessBoard').height() / 4;
    $('#mainChessBoard td').css('height', height);
    $('#mainChessBoard td').css('width', height);*/


    var whiteCoins = new Array();
    whiteCoins[0] = $("#a2").html();
    whiteCoins[1] = $("#a1").html();
    whiteCoins[2] = $("#b1").html();
    whiteCoins[3] = $("#c1").html();
    whiteCoins[4] = $("#d1").html();
    whiteCoins[5] = $("#e1").html();

    var blackCoins = new Array();
    blackCoins[0] = $("#a7").html();
    blackCoins[1] = $("#a8").html();
    blackCoins[2] = $("#b8").html();
    blackCoins[3] = $("#c8").html();
    blackCoins[4] = $("#d8").html();
    blackCoins[5] = $("#e8").html();


    var count = 0;
    var storeBuffer = "";
    var bufferStore = "";
    var buffer = "";
    var currentDown = "";
    var currentUp = "";
    var prevDown = "";
    var prevUp = "";
    var killedCoins = "";

    $("body").live('selectstart dragstart', function (e) { e.preventDefault(); return false; });

    $("#mainChessBoard td").click(function () {
        if (buffer == "") {
            if ($(this).text().length == 0) {
                buffer = "";
            }
            else {

                buffer = $.trim($(this).html());



                if (count % 2 == 0) {
                    if ($.inArray(buffer, blackCoins) > -1) {
                        buffer = "";
                    }
                    else {
                        currentUp = "#" + $(this).attr("id");
                        clickablePosition();

                    }

                }
                else {
                    if ($.inArray(buffer, whiteCoins) > -1) {
                        buffer = "";
                    }
                    else {
                        currentUp = "#" + $(this).attr("id");
                        clickablePosition();
                    }
                }

                function clickablePosition() {
                    $(currentUp).css("border-color", "cornflowerblue");


                    $("#mouseDiv").html(buffer);
                    $(currentUp).text('');



                    $("#mainChessBoard td").hover(function () {

                        if ($(currentUp)) {
                            $(currentUp).stop(true, false).css("border-color", "cornflowerblue");
                            $(prevUp).stop(true, false).css("border-color", "orange");
                            $(prevDown).stop(true, false).css("border-color", "cornflowerblue");
                        }
                        $(this).stop(true, false).css("border-color", "black");

                    }, function () {
                        $(this).stop(true, false).css("border-color", "white");
                    });
                }



            }
        }

        else {
            currentDown = "#" + $(this).attr("id");
            storeBuffer = $.trim($(this).html());
            var flag = 0;
            if ($.inArray(buffer, whiteCoins) > -1 && $.inArray(storeBuffer, whiteCoins) > -1) {
                flag = 1;
            }
            else if ($.inArray(buffer, blackCoins) > -1 && $.inArray(storeBuffer, blackCoins) > -1) {
                flag = 1;
            }
            if (flag == 0) {

                $(this).html(buffer);
                buffer = "";
                if (currentDown == currentUp) {
                    $(currentDown).css("border-color", "white");
                }
                else {
                    $(currentDown).css("border-color", "cornflowerblue");
                    $(currentUp).css("border-color", "orange");
                    $(prevUp).css("border-color", "white");
                    $(prevDown).css("border-color", "white");
                    prevUp = currentUp;
                    prevDown = currentDown;
                    count++;
                }
            }
            else {
                //if (currentDown == currentUp) {
                $(currentUp).css("border-color", "white");
                $(currentDown).css("border-color", "white");
                //}
                /*else {
                count++;
                }*/
                $(this).html(storeBuffer);
                $(currentUp).html(buffer);
                buffer = "";
                flag = 0;
            }
            /*if (storeBuffer != "") {
                if ($.inArray(buffer, whiteCoins) != -1 && $.inArray(storeBuffer, whiteCoins) != -1) {
                    killedCoins = killedCoins + '<br>' + storeBuffer;
                    $('#gameStatus').html(killedCoins);
                }
                else if ($.inArray(buffer, blackCoins) != -1 && $.inArray(storeBuffer, blackCoins) != -1) {
                    killedCoins = killedCoins + '<br>' + storeBuffer;
                    $('#gameStatus').html(killedCoins);
                }
            }*/
            /* previous positions NULL */
            $("#mainChessBoard td").unbind("hover");
            $("#mouseDiv").html('');

        }
    });
    $(document).bind('mousemove', function (e) {
        $('#mouseDiv').css({
            left: e.pageX + 5,
            top: e.pageY + 5
        });

    });
    $("#mainChessBoard td").bind('mousemove', function () {
        var hoverThing = $(this).html();
        if ($(this).text().length > 0) {//$.inArray(hoverThing, whiteCoins) > -1 || $.inArray(hoverThing, blackCoins) > -1) {
            $(this).css("cursor", "pointer");
        }
        else {
            $(this).css("cursor", "default");
        }
    });
}); 



