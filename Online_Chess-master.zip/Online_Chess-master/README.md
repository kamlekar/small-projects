Online Chess 
============

###Description:

- A simple online chess game. (work in progress)

###Technology:

- HTML, CSS and Javascript.

###Done:

- Chess coin movements on the board.
- "Can't kill your own kind" function.
- Previous step data.

###Undone:

- Chess coin movement highlight.
- Alternate play.
- Multiplayer. 

###[Demo](https://rawgithub.com/venkateshwar/Online_Chess/master/index.html)

###Note: 

- I am testing this project only in Chrome.


