
(function (_) {

	window.onload = function(){
		_.buffer = "";
		/* array to assign numbers to the chess boxes */
		_.alpha = ["a","b","c","d","e","f","g","h"];
		_.num = ["1","2","3","4","5","6","7","8"];
		//Adding the cursor div to the body tag.
		_.divAlong = document.createElement('div');
		_.divAlong.className = "cursorDiv";
		_.curRep = {d : 5};
		document.body.appendChild(_.divAlong);
		//
		//Assigning values inside the whiteCoins and blackCoins arrays
		_.wC = ["\u2654", "\u2655", "\u2656", "\u2657", "\u2658", "\u2659"];//["&#9812;", "&#9813;", "&#9814;", "&#9815;", "&#9816;", "&#9817;"];
		_.bC = ["\u265a", "\u265b", "\u265c", "\u265d", "\u265e", "\u265f"];//["&#9818;", "&#9819;", "&#9820;", "&#9821;", "&#9822;", "&#9823;"];
		//
		//Initializing variables
		_.chessBoard = core.el.elCls(document, 'chessBoard')[0];
		_.chessMain = core.el.elCls(_.chessBoard, 'chessMain')[0];
		_.chessMainIn = core.el.elCls(_.chessBoard, 'chessMainIn')[0];
		_.rightRule = core.el.elCls(_.chessBoard, 'rightRule')[0];
		_.dmyRule = core.el.elCls(_.chessBoard, 'dmyRule')[0];
		_.btmRule = core.el.elCls(_.chessBoard, 'btmRule')[0];
	
		//Creating appending elements
		(_.block = document.createElement('div')).setAttribute('class','outBlock');
		(_.inBlock = document.createElement('div')).setAttribute('class','inBlock');
		_.block.appendChild(_.inBlock);
		
		
		//appending 64 child elements to the chess board
		//Add black and white colors to the blocks
		//Initialize coins
		var fragment = document.createDocumentFragment();
		var count = 0;
		for (var i = 0; i < 64; i++,count++) {
			var cloneNd = _.block.cloneNode(true);
			if(i%8 == 0){
				count++;
			}
			//Assign Id's to each block
			assignBoxId(cloneNd,i);
			cloneNd.className += count%2 == 0?" blackBox":" whiteBox";
			cloneNd.firstChild.className += count%2 == 0?" blackBox":" whiteBox";
			setCoins(cloneNd.firstChild, i);
			fragment.appendChild(cloneNd);
		}
		_.chessMainIn.appendChild(fragment);	
		setDimensions();
		
		//Keep a div along with the cursor always on chessBoard
		bindEvent(_.chessBoard, "mouseover", cursorDiv);
		//click event on chessboard boxes
		var box = _.chessMainIn.getElementsByClassName('inBlock');
		for(var i = 0; i < box.length; i++){
			//debugger;
			//var inBox = box[i].getElementsByTagName('div')[0];
			bindEvent(box[i], "click", boxClick);
		}
	}

	window.onresize = setDimensions;
	function boxClick(){
		var self = this;
		if(_.buffer == ""){
			_.buffer = self.innerHTML;
			self.innerHTML = "";
			_.divAlong.innerHTML = _.buffer;			
			if(_.buffer){
				if(boxClick.prevEndPoint){
					//reset the paint of the previous end box.
					resetPoint(boxClick.prevEndPoint);
				}
				if(boxClick.prevStartPoint){
					//reset the paint of the previous start box.
					resetPoint(boxClick.prevStartPoint);
				}
				//paint the current element as end box.
				endPoint(self);
				//Store the current element as previous start point.
				boxClick.prevStartPoint = self;
			}
		}
		else {
			//Enters in this statement if the buffer has variable
			var iH = self.innerHTML;
			if(_.wC.indexOf(_.buffer) > -1 && _.wC.indexOf(iH) > -1){
				//show popup for "can't kill your own kind" function
				alert("Can't kill your own kind");
			}
			else if(_.bC.indexOf(_.buffer) > -1 && _.bC.indexOf(iH) > -1){
				//show popup for "can't kill your own kind" function
				alert("Can't kill your own kind");
			}
			else{
				self.innerHTML = _.buffer;
				_.buffer = "";
						
				_.divAlong.innerHTML = _.buffer;
				//paint current element as end point box
				startPoint(self);	
				//Store the current element as previous element.
				boxClick.prevEndPoint = self;
			}
		}
	}
	function setDimensions(){
		//adjust width and height of the blocks and chessMainIn dynamically
		if(_.chessMainIn){
			var box = _.chessMainIn.getElementsByClassName('outBlock');
			_.chessBoard.style.height = window.innerHeight + "px";
			_.chessMain.style.height = (window.innerHeight - _.btmRule.offsetHeight) + "px";
			_.rightRule.style.height = _.chessMain.style.height;
			var chessBlockWidth = _.chessMainIn.offsetHeight;
			_.btmRule.style.width = chessBlockWidth + "px";			
			_.chessMainIn.style.width = chessBlockWidth + "px";
			//_rightRule.style.height = chessBlockWidth + "px";
			var cBW = chessBlockWidth/8 + "px";
			for(var i=0; i<box.length; i++){
				var subBox = box[i];
				subBox.style.width = cBW;
				subBox.style.height = cBW;						
				subBox.style.lineHeight = cBW;
			}
			_.chessMain.style.fontSize = chessBlockWidth/16 + "px";
			_.divAlong.style.fontSize = chessBlockWidth/16 + "px";
			_.chessMain.style.width = chessBlockWidth + "px";
			//calculating width of chess board based on the child elements
			_.chessBoard.style.width = _.chessMain.offsetWidth + _.rightRule.offsetWidth + "px";
		}
	}
	function assignBoxId(box,i){
		var j = i%8;
		var c = _.alpha[j] + _.num[7-j];
		box.className += " out" + c;
		box.firstChild.className += " in" + c;
	}
	
	function cursorDiv(e){
		//debugger;
		_.divAlong.style.top = e.pageY + _.curRep.d + "px";
		_.divAlong.style.left = e.pageX + _.curRep.d + "px";		
	}
	function bindEvent(e, type, handler) {
		if(e.addEventListener) {
			e.addEventListener(type, handler, false);
		} else {
			e.attachEvent('on'+type, handler);
		}
	}
	function resetPoint(el){
		el.parentElement.style.backgroundColor = el.style.backgroundColor;
	}
	function startPoint(el){
		el.parentElement.style.backgroundColor = "green";
	}
	
	function endPoint(el){
		el.parentElement.style.backgroundColor = "orange";
	}
	
	function setCoins(el, i){
		if(i == 0){
			el.innerHTML = _.wC[2];
		}
		else if(i == 1){
			el.innerHTML = _.wC[4];
		}
		else if(i == 2){
			el.innerHTML = _.wC[3];
		}
		else if(i == 3){
			el.innerHTML = _.wC[1];
		}
		else if(i == 4){
			el.innerHTML = _.wC[0];
		}
		else if(i == 5){
			el.innerHTML = _.wC[3];
		}
		else if(i == 6){
			el.innerHTML = _.wC[4];
		}
		else if(i == 7){
			el.innerHTML = _.wC[2];
		}
		else if(i > 7 && i < 16){
			el.innerHTML = _.wC[5];
		}
		else if(i > 47 && i < 56){
			el.innerHTML = _.bC[5];
		}
		else if(i == 56){
			el.innerHTML = _.bC[2];
		}
		else if(i == 57){
			el.innerHTML = _.bC[4];
		}
		else if(i == 58){
			el.innerHTML = _.bC[3];
		}
		else if(i == 59){
			el.innerHTML = _.bC[1];
		}
		else if(i == 60){
			el.innerHTML = _.bC[0];
		}
		else if(i == 61){
			el.innerHTML = _.bC[3];
		}
		else if(i == 62){
			el.innerHTML = _.bC[4];
		}
		else if(i == 63){
			el.innerHTML = _.bC[2];
		}
	}
})(window);