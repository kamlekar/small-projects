
var core = {
	el : {
		elId : function(p, id){
			return p.getElementById(id);
		},
		elCls : function(p, cls){
			return p.getElementsByClassName(cls);
		}
	}
}



// (function (window) {
	// var core = {};

	// core.id = function (element, id) {
		// return element.getElementById(id);
	// };

	// core.cName = function (element, className) {
		// return element.getElementsByClassName(className);
	// };

	// window.mySuperTool= core;
// })(window);



// (function (core) {
	// var trout = core.id(document, 'trout');
	// trout.parentNode.removeChild(trout);
// })(window.mySuperTool);
