	$(function () {			
		var _selectedDivId;
		var _randomNumber;
		//
		var _maxNumber = 13;
		var _counter = 0;
		var _subValue = 3;
		var _idGen = 1;
		var _idCount = 1;
		//					
		var _clickedBlock = 45;  //stores the Id of the clicked block by the user.
		//creating div's dynamically inside the #main div
		var value = '#main';
		//creating Nested div's inside the #main div
		for (var count = 0; count < _subValue; count++) {
			for (var subCount = 0; subCount < _subValue; subCount++) {
				$(value).append('<div><div></div></div>');
			}
		}

		//adding two more nested div's inside the above created Nested div's of #main div for the small element section's which stores the numbers.
		$(value + '>div>div')
			.each(function () {
			for (var subCount = 0; subCount < _subValue * _subValue; subCount++) {
				$(this).append('<div><button id="' + _idGen + '"></button></div>');
				var lastNumId = _idGen % 10;		//stores the last digit of the number
				var secondLastNumId = 0;
				if(_idGen>9){
					secondLastNumId = (_idGen - lastNumId)/10;	//stores the second last digit of the number							
				}
				//checking if the elements are being generated adjacent or at down
				//The below if statement is true, if the elements are generating one step(3 blocks) down
				if (lastNumId % (_subValue * _subValue) == 0 && (secondLastNumId + 1) % _subValue == 0) {
					//adding extra value which will be removed after the for loop execution
					//This is mainly for normalizing the id values.
					_idGen += _subValue * _subValue * _subValue;
					_idGen++;
				}
				//The below statement executes if the elements are generating after three elements ie., down in the same block
				else if (lastNumId % _subValue == 0) {
					_idGen += _subValue * (_subValue - 1);
					_idGen++;
				}
				_idGen++;
			}
			//removing extra value for counting at down.
			_idGen -= _subValue * _subValue * _subValue;
		});

		//filling the numbers after successfully assigning the div Id's
		selectRandomDiv();




		function selectRandomDiv() {
			do {
				//selecting a random div from the assigned Id's
				_selectedDivId = Math.ceil(Math.random(1) * 100);
			} while (_selectedDivId % 10 == 0 || _selectedDivId > 89)
			//
			
			var selectedDiv = $('#' + _selectedDivId);
			if (selectedDiv.html() == "") {
				//call the below function to generate a random number in the range 0 to 9. and also sudoku validations.
				validateGeneratedRandomNumber();

				//after successful completion of the above method, the generated random number will be assigned to the selected div.
				selectedDiv.html('<strong>' + _randomNumber + '</strong>');
				//Count how many times the div's are assigned and give a limit.
				_counter++;
				//For example: if(Counter>9) then "stop" else "recursive call".
				if (_counter < _maxNumber) {
					selectRandomDiv();
				} 
				giveBorder("#" + _clickedBlock);
				//else End of Operation.
			}
			else{
				selectRandomDiv();
			}					
		}

		function validateGeneratedRandomNumber() {
			do {
				//generating a random number of single digit (non-zero)
				_randomNumber = parseInt(Math.ceil(Math.random(1) * 100).toString().substr(-1), 10);
			} while (_randomNumber == 0 || _randomNumber > 9);
			//
			//Before assigning the selected random number to the selected div,
			//Check whether the random number is already present in the block in which the selected div is present.
			checkInGroup();
			//
			//Check whether the random number is already present in the horizontal line of the selected div.
			checkHorizontalLine();
			//
			//Check whether the random number is already present in the vertical line of the selected div.
			checkVerticalLine();
		}



		function checkInGroup() {
			var selectedDiv = $('#' + _selectedDivId);
			//calling the parent element and checkin all the child elements for the presence of random number
			selectedDiv.parent("div").parent("div").find("button").each(function () {
				//unchecking the selected div
				if (this !== selectedDiv[0]) {
					var self = $(this);
					if (self.html().indexOf(_randomNumber.toString()) != -1) {
						//if any div inside the parent block has the same random number assigned then
						//Calling the recursive function without assigning the random number to the selected div.
						validateGeneratedRandomNumber();
					}
				}
			});
		}

		function checkHorizontalLine() {
			//check for the random value is already present in the block.
			var selectedDiv = $('#' + _selectedDivId);
			var firstDigit;
			if (_selectedDivId < 10) {
				firstDigit = "";
			} else {
				firstDigit = parseInt(_selectedDivId.toString().charAt(_selectedDivId.length - 2), 10);
			}

			var secondDigit = parseInt(_selectedDivId.toString().substr(-1), 10);
			for (var intCount = 1; intCount < 10; intCount++) {
				try {
					var check = $('#' + firstDigit + intCount).html();
					//aborting operation on the selected div
					if (firstDigit.toString() + intCount.toString() == _selectedDivId.toString()) {
						continue;
					} else if (check.indexOf(_randomNumber.toString()) != -1) {
						//if other div in the horizontal line of the selected div has the same random number 
						//assigned then calling the recursive function without assigning the random number to the selected div.
						validateGeneratedRandomNumber();
					}
				} catch (err) {
					//Chrome execution (testing purpose)
					//console.log("Hor: " + firstDigit + " " + intCount + ": " + _selectedDivId);
				}
			}
		}

		function checkVerticalLine() {
			//check for the random value is already present in the block.
			var selectedDiv = $('#' + _selectedDivId);
			var firstDigit = parseInt(_selectedDivId.toString().charAt(_selectedDivId.length - 2), 10);
			var secondDigit = parseInt(_selectedDivId.toString().substr(-1), 10);				
			//check for the random value present in the vertical line of the selected div.
			for (var intCount = 1; intCount < 9; intCount++) {
				try {
					var check = $('#' + intCount + secondDigit).text();
					if (intCount.toString() + secondDigit.toString() == _selectedDivId.toString()) {
						continue;
					} else if (check.indexOf(_randomNumber.toString()) != -1) {
						//if other div in the Vertical line of the selected div has the same random number 
						//assigned then calling the recursive function without assigning the random number to the selected div.
						validateGeneratedRandomNumber();
					}
				} catch (err) {
					//Chrome execution (testing purpose).
					//console.log("Ver: " + intCount + " " + secondDigit);
				}
			}
		}
		
		
		
		/*************************************************************************/
		/*****************Operation Code *****************************************/
		/*************************************************************************/
		
		
		
		$('#main').on('click','button',function(){	
			giveBorder(this);
		});
		
		$('body').on('keydown',function(e){			
			keyPress(e);
		});
		
		function giveBorder(data){
			$('button').css({border:'none'});
			var self = $(data);
			//alert("give border: " + self.html());
			if(self.html().indexOf("STRONG") == -1 && self.html().indexOf("strong") == -1){
			//if(jQuery("strong",self.html().toArray()) == -1){
				self.css({border:'1px solid green'});
			}
			else{
				self.css({border:'1px solid red'});
			}
			_clickedBlock = self.prop("id");
		}
		
		function keyPress(e){
			var clickedBlock = $('#' + _clickedBlock);
			var charCode = (e.which) ? e.which : event.keyCode;
			if (charCode > 48 && charCode < 58){					
				if(clickedBlock.html().indexOf("STRONG") == -1 && clickedBlock.html().indexOf("strong") == -1){
					var simpleNumber = 48;
					clickedBlock.html(charCode - simpleNumber);
				}
			}
			else if(charCode > 96 && charCode < 106){
				if(clickedBlock.html().indexOf("STRONG") == -1 && clickedBlock.html().indexOf("strong") == -1){
					var numpadNumber = 96;
					clickedBlock.html(charCode - numpadNumber);
				}
			}	
			else if(charCode == 46 || charCode == 8){
				clickedBlock.html("");
			}					
		
			//left
			else if (charCode == 37) {
				if(_clickedBlock == 1){
					//sending to last block.
					_clickedBlock = 89;
				}
				else if((_clickedBlock - 1) % 10 == 0){
					_clickedBlock = _clickedBlock - 2;
				}
				else{
					_clickedBlock--;
				}
				giveBorder("#" + _clickedBlock);
			}
			//up
			else if (charCode == 38) { 
				if(_clickedBlock < 10){
					//sending to last blocks line
					_clickedBlock = parseInt(_clickedBlock,10) + 80;
				}
				else{
					_clickedBlock -= 10;
				}
				giveBorder("#" + _clickedBlock);
			}
			//right
			else if (charCode == 39) { 
				if(_clickedBlock == 89){
					//sending to last block.
					_clickedBlock = 1;
				}
				else if((parseInt(_clickedBlock,10) + 1) % 10 == 0){
					_clickedBlock = parseInt(_clickedBlock,10) + 2;
				}
				else{
					_clickedBlock++;
				}
				giveBorder("#" + _clickedBlock);
			}
			//down
			else if (charCode == 40) { 
				if(_clickedBlock > 80){
					//sending to last blocks line
					_clickedBlock = parseInt(_clickedBlock,10) - 80;
				}
				else{
					_clickedBlock = parseInt(_clickedBlock,10) + 10;
				}
				giveBorder("#" + _clickedBlock);
			}
		}
	});