###jQuery Sudoku

This is a simple Sudoku game created using jQuery 1.8.3.

Compatible with Google Chrome and >IE8
