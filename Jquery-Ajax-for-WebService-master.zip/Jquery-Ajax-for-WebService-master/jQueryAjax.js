<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Example.aspx.cs" Inherits="ExampleJsonApp.Example" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <script src="Scripts/jquery-1.8.3.min.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function () {

        });
//        jQuery.support.cors = true;
        function btnClick() {
            debugger;
            var txtValue = $('#txtValue');
            var text = txtValue.val();
            //
            //
            $.ajax({
                url: "http://localhost:12000/ExampleJsonWS.asmx/getValue",
                type: "POST",
                dataType: "json",
                data: "{" + txtValue.val() + "}",
                timeout: 30000,
                async: false,
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    debugger;
                    alert(data);
                    return data;
                },
                error: function (result) {
                    debugger;
                    //alert(e);
                    alert(result.status + ' ' + result.statusText);
                }
            });
        }
    </script>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        <asp:TextBox ID="txtValue" runat="server"></asp:TextBox>
        <asp:Button ID="btnSubmit" runat="server" Text="Submit" OnClientClick="btnClick();" />
    </div>
    </form>
</body>
</html>
