Windows-7-calculator
====================
