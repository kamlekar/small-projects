SignalR-Chat-application
========================

This is a chat application modified by going through https://github.com/SignalR/SignalR/wiki/QuickStart-Hubs
